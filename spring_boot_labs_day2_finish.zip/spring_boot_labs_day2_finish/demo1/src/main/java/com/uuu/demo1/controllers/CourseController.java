package com.uuu.demo1.controllers;

import com.uuu.demo1.forms.CourseForm;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.config.annotation.ViewControllerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Controller
@Slf4j
public class CourseController implements WebMvcConfigurer {
    @Override
    public void addViewControllers(ViewControllerRegistry registry) {
        WebMvcConfigurer.super.addViewControllers(registry);
        registry.addViewController("/results").setViewName("success");
    }

    @GetMapping("/course")
    public String showCourseForm(CourseForm f) {
//        f.setCourseId("OO226");
//        f.setCourseName("Java and OOP");
//        f.setDuration(35);
        return "courseForm";
    }

    @PostMapping("/course")
    public String handleCourseFormSubmit(@Valid CourseForm f, BindingResult result) {
        if (result.hasErrors()) {
            log.info("oops, error happened, count={}, proceed", result.getErrorCount());
            for (var error : result.getAllErrors()) {
                log.info("error object={}, field={}", error.getObjectName(),error.getArguments());
            }
            return "courseForm";

        }
        log.info("傳送過來的Course是:{}", f);
        return "redirect:/results"; // this is bad, need to fix later
    }
}
