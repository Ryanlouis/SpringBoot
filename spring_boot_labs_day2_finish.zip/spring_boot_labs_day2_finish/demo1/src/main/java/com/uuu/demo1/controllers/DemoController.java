package com.uuu.demo1.controllers;


import com.uuu.demo1.beans.Course;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@Controller
@Slf4j
public class DemoController {
    private static final String MESSAGE = "message";
    private static final String MESSAGE2 = "message2";
    private static final String INFO_KEY1 = "jcourse";
    @Value("${main.course.name}")
    private String courseName;
    @Value("${main.course.limit}")
    private Integer courseLimit;
    private static final Logger LOG = LoggerFactory.getLogger(DemoController.class);

    @GetMapping("/")
    public String index(Model model) {
        model.addAttribute(MESSAGE, "Hi, 我是Mark Ho");
        model.addAttribute(MESSAGE2, "learning spring");
        return "home";
    }

    @GetMapping("/info")
    public String info(Model m) {
        System.out.printf("course name=%s\n", courseName);
        log.info("course name={}, double course limit={}", courseName, courseLimit * 2);
        LOG.info("COURSE NAME={}, triple course limit={}", courseName, courseLimit * 3);
        Course course = new Course();
        course.setId("SL275");
        course.setDuration("35hr");
        course.setFee("24000NTD");
        course.setName("Java and OOP");
        m.addAttribute(INFO_KEY1, course);
        return "info/contact";
    }
}
