package com.uuu.demo1;

import com.uuu.demo1.beans.NormalUser1;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validation;
import jakarta.validation.Validator;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import java.util.Set;

//import javax.xml.validation.Validator;

public class Demo6Test {
    private static Validator validator;

    @BeforeAll
    public static void prepareValidator() {
        validator = Validation.buildDefaultValidatorFactory().getValidator();
    }

    @Test
    public void createNormalUser1() {
        NormalUser1 user = new NormalUser1();
        Assertions.assertNull(user.getName());
    }

    @Test
    public void checkNullAssertionShouldTrigger() {
        NormalUser1 user = new NormalUser1();
        Set<ConstraintViolation<NormalUser1>> violations = validator.validate(user);
        for (var v : violations) {
            System.out.printf("find a violation:%s\n", v.getMessage());
        }
        Assertions.assertEquals(1, violations.size());
    }
    @Test
    public void checkEmptyIsNull() {
        NormalUser1 user = new NormalUser1();
        user.setName("");
        Set<ConstraintViolation<NormalUser1>> violations = validator.validate(user);
        for (var v : violations) {
            System.out.printf("find a violation:%s\n", v.getMessage());
        }
        Assertions.assertEquals(0, violations.size());
    }
    @Test
    public void checkSpaceIsNull() {
        NormalUser1 user = new NormalUser1();
        user.setName("     \t");
        Set<ConstraintViolation<NormalUser1>> violations = validator.validate(user);
        for (var v : violations) {
            System.out.printf("find a violation:%s\n", v.getMessage());
        }
        Assertions.assertEquals(0, violations.size());
    }
    @Test
    public void checkStuffIsNull() {
        NormalUser1 user = new NormalUser1();
        user.setName("www.uuu.com.tw");
        Set<ConstraintViolation<NormalUser1>> violations = validator.validate(user);
        for (var v : violations) {
            System.out.printf("find a violation:%s\n", v.getMessage());
        }
        Assertions.assertEquals(0, violations.size());
    }
}
