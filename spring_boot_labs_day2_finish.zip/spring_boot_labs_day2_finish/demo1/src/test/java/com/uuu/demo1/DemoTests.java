package com.uuu.demo1;

import org.junit.jupiter.api.*;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class DemoTests {
    @BeforeAll
    public static void prepareOnce() {
        System.out.println("一次性的啟動");
    }

    @AfterAll
    public static void finalCleanUp() {
        System.out.println("最後的最後收尾");
    }

    @BeforeEach
    public void prepare() {
        System.out.println("一些準備工作");
    }

    @AfterEach
    public void cleanup() {
        System.out.println("收尾");
    }

    @Test
    public void doATest() {
        System.out.println("test something first");
    }

    @Test
    public void doAnotherTest() {
        System.out.println("test something later");
    }
    @Disabled("skip1")
    @Test
    public void doATestThatNotYetImplement() {
        Assertions.fail();
    }
    @Disabled("skip2")
    @Test
    public void doATestThatNotYetImplementWithReason() {
        Assertions.fail("下一Q會實作");
    }
    @Disabled("skip3")
    @Test
    public void doATestThatHasException() {
        throw new RuntimeException();
    }
}
