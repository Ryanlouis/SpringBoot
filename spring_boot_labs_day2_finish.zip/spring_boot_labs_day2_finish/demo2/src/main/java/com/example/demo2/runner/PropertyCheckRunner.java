package com.example.demo2.runner;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class PropertyCheckRunner implements CommandLineRunner {
    @Value("${spring.profiles.active}")
    private String profile;
    @Value("${greeting}")
    private String greeting;

    @Override
    public void run(String... args) throws Exception {
        log.info("spring的profile是:{}", profile);
        log.info("greeting的值是:{}", greeting);
    }
}
