package com.example.demo3.config;

import com.example.demo3.calculator.AddCalculator;
import com.example.demo3.calculator.Calculator;
import com.example.demo3.calculator.SubCalculator;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AppConfig {
//    @Bean
//    public Calculator cal1() {
//        return new AddCalculator();
//    }

    @Bean
    public Calculator cal2() {
        return new SubCalculator();
    }
}
