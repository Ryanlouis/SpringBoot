package com.example.demo3.controllers;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class RestController1 {
    @RequestMapping(path = "/", method = RequestMethod.GET)
    String getHome() {
        return "[GET]Hello World123";
    }

    @RequestMapping(path = "/", method = RequestMethod.POST)
    String postHome() {
        return "[POST]Hello World456";
    }
}
