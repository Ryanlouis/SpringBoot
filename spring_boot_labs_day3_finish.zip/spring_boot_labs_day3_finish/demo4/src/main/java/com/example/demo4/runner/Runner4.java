package com.example.demo4.runner;

import com.example.demo4.bean.User;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.annotation.Order;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Component
@Slf4j
@Order(4)
public class Runner4 implements CommandLineRunner {
    @Autowired
    private JdbcTemplate template;
    private static final String CREATE_DDL = "CREATE TABLE users(id SERIAL, username VARCHAR(255), password VARCHAR(255))";
    private static final String DROP_DDL = "DROP TABLE users IF EXISTS";
    // sample data
    private static final String USER1 = "Mark pwd1";
    private static final String USER2 = "Tim pwd2";
    private static final String USER3 = "Ken pwd3";
    private static final String USER4 = "John pwd4";
    // inser SQL
    private static final String INSERT_DML = "INSERT INTO users( username, password ) VALUES (?,?)";
    // query DML
    private static final String SELECT_DML = "SELECT * FROM users";
    private static final String SELECT_DML2 = "SELECT id, username, password FROM users WHERE username = ?";

    @Override
    public void run(String... args) throws Exception {
        template.execute(DROP_DDL);
        template.execute(CREATE_DDL);
        List<String> originalUsers = Arrays.asList(USER1, USER2, USER3, USER4);
        List<Object[]> users = originalUsers.stream().map(s -> s.split(" ")).collect(Collectors.toList());
        users.forEach(array -> log.info("will insert username:{}, password:{}", array[0], array[1]));
        template.batchUpdate(INSERT_DML, users);
//        List<User> totalUsers = template.query(SELECT_DML, (rs, rowNum) -> {
//            log.info("rowNum={},rs={}", rowNum, rs);
//            String username = rs.getString("username");
//            String password = rs.getString("password");
//            log.info("username={},password={}", username, password);
//            return new User(username, password);
//        });
        List<User> totalUsers = template.query(SELECT_DML, (rs, rowNum) -> new User(
                rs.getString("username"), rs.getString("password")
        ));
        totalUsers.forEach(x -> log.info("total user, current user={}", x));
        template.query(SELECT_DML, (rs, rowNum) -> new User(
                rs.getString("username"), rs.getString("password")
        )).forEach(user -> log.info("in stream current user={}", user));
        User user = template.queryForObject(SELECT_DML2, (rs, rowNum) -> new User(
                rs.getString("username"), rs.getString("password")
        ), new Object[]{"Ken"});
        log.info("query 'Ken', result={}", user);
    }
}
