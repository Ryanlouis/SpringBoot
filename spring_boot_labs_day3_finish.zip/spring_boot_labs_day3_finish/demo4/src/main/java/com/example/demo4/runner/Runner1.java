package com.example.demo4.runner;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.annotation.Order;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Component;

import java.sql.Connection;

@Component
@Slf4j
@Order(1)
public class Runner1 implements CommandLineRunner {
    @Autowired
    NamedParameterJdbcTemplate template;
    private static final String SQL1 = "SELECT 1234+4321";

    @Override
    public void run(String... args) throws Exception {
//        log.info("template={}", template);
//        log.info("template datasource={}", template.getJdbcTemplate().getDataSource());
//        Connection connection1 = template.getJdbcTemplate().getDataSource().getConnection();
//        log.info("datasource connection={}", connection1);
//        connection1.close();
        SqlParameterSource source = new MapSqlParameterSource();
        Integer intResult = template.queryForObject(SQL1, source, Integer.class);
        log.info("execute {}, result={}", SQL1, intResult);
    }
}
