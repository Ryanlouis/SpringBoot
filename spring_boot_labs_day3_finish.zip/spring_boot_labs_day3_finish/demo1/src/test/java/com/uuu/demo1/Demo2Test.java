package com.uuu.demo1;

import com.uuu.demo1.controllers.DemoController;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class Demo2Test {
    @Autowired
    private DemoController controller;

    @Test
    public void checkDemoControllerNotNull() {
        Assertions.assertNotNull(controller);
    }
}
