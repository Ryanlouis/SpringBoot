package com.uuu.demo1;

import com.uuu.demo1.controllers.GreetController;
import com.uuu.demo1.services.GreetingService;
import org.hamcrest.Matchers;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

//@SpringBootTest
//@AutoConfigureMockMvc
@WebMvcTest(controllers = GreetController.class)
public class Demo5Test {
    @Autowired
    private MockMvc mockMvc;
    @MockitoBean
    private GreetingService service;

    @Test
    public void mockMvcShouldNotNull() {
        Assertions.assertNotNull(mockMvc);
    }

    @Test
    public void performGreet() throws Exception {
        String testString = "hello world";
        Mockito.when(service.greet()).thenReturn(testString);
        mockMvc.perform(MockMvcRequestBuilders.get("/greeting"))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.content().string(
                        Matchers.containsString(testString)
                ))
        ;
    }
}
