package com.uuu.demo1;

import com.uuu.demo1.beans.NormalUser3;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validation;
import jakarta.validation.Validator;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import java.util.Set;

//import javax.xml.validation.Validator;

public class Demo8Test {
    private static Validator validator;

    @BeforeAll
    public static void prepareValidator() {
        validator = Validation.buildDefaultValidatorFactory().getValidator();
    }

    @Test
    public void createNormalUser3() {
        NormalUser3 user = new NormalUser3();
        Assertions.assertNull(user.getName());
    }

    @Test
    public void checkNullAssertionShouldTrigger() {
        NormalUser3 user = new NormalUser3();
        Set<ConstraintViolation<NormalUser3>> violations = validator.validate(user);
        for (var v : violations) {
            System.out.printf("find a violation:%s\n", v.getMessage());
        }
        Assertions.assertEquals(1, violations.size());
    }
    @Test
    public void checkEmptyIsNull() {
        NormalUser3 user = new NormalUser3();
        user.setName("");
        Set<ConstraintViolation<NormalUser3>> violations = validator.validate(user);
        for (var v : violations) {
            System.out.printf("find a violation:%s\n", v.getMessage());
        }
        Assertions.assertEquals(1, violations.size());
    }
    @Test
    public void checkSpaceIsNull() {
        NormalUser3 user = new NormalUser3();
        user.setName("     \t");
        Set<ConstraintViolation<NormalUser3>> violations = validator.validate(user);
        for (var v : violations) {
            System.out.printf("find a violation:%s\n", v.getMessage());
        }
        Assertions.assertEquals(1, violations.size());
    }
    @Test
    public void checkStuffIsNull() {
        NormalUser3 user = new NormalUser3();
        user.setName("www.uuu.com.tw");
        Set<ConstraintViolation<NormalUser3>> violations = validator.validate(user);
        for (var v : violations) {
            System.out.printf("find a violation:%s\n", v.getMessage());
        }
        Assertions.assertEquals(0, violations.size());
    }
}
