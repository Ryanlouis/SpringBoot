package com.uuu.demo1.controllers;

import org.springframework.stereotype.Controller;

@Controller
public class FakeController {
}
