package com.example.demo3.controllers;

import com.example.demo3.beans.Message;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Date;

@RestController
@Slf4j
public class WelcomeController {
    @Autowired
    private Message message;

    @GetMapping("/welcome")
    ResponseEntity<?> home() {
        log.info("message hash={}", message.hashCode());
        message.setCost(4.5f);
        message.setValid(true);
        message.setDate(new Date());
        message.setDetail("試試萬國碼");
        return new ResponseEntity<>(message, HttpStatus.OK);
    }
}
