package com.example.demo3.runner;

import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

@Component
@Slf4j
@Order(6)
public class ExplainLog implements CommandLineRunner {
    @Override
    public void run(String... args) throws Exception {
        log.trace("this is a log");
        log.debug("this is a log");
        log.info("this is a log");
        log.warn("this is a log");
        log.error("this is a log");
    }
}
