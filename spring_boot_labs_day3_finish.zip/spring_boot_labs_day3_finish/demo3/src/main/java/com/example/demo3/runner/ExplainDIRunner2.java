package com.example.demo3.runner;

import com.example.demo3.calculator.Calculator;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

@Component
@Slf4j
@Order(2)
public class ExplainDIRunner2 implements CommandLineRunner {

    private final Calculator cal1;
    private final Calculator cal2;

    public ExplainDIRunner2(@Qualifier("add") Calculator cal1,
                            @Qualifier("sub") Calculator cal2) {
        this.cal1 = cal1;
        this.cal2 = cal2;
    }

    @Override
    public void run(String... args) throws Exception {
        log.info("calculate 3,4 with cal1={}", cal1.calc(3, 4));
        log.info("calculate 3,4 with cal2={}", cal2.calc(3, 4));
    }
}
