package com.example.demo3.runner;

import com.example.demo3.calculator.Calculator;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.ApplicationContext;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

@Component
@Slf4j
@Order(1)
public class ExplainDIRunner1 implements CommandLineRunner {
    @Autowired
    private ApplicationContext context;

    @Override
    public void run(String... args) throws Exception {
        Calculator c1 = context.getBean("add", Calculator.class);
        log.info("c1 with 1,2={}", c1.calc(1, 2));
        Calculator c2 = context.getBean("sub", Calculator.class);
        log.info("c2 with 1,2={}", c2.calc(1, 2));
    }
}
