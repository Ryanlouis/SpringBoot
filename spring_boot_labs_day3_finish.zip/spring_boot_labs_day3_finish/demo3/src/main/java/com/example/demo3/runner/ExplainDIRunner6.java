package com.example.demo3.runner;

import com.example.demo3.race.Bicycle;
import com.example.demo3.race.Bike;
import com.example.demo3.race.Racing;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

@Component
@Slf4j
@Order(6)
public class ExplainDIRunner6 implements CommandLineRunner {
    public ExplainDIRunner6(@Qualifier("bicycle") Racing r1, @Qualifier("bike") Racing r2) {
        this.r1 = r1;
        this.r2 = r2;
        this.b1 = (Bicycle) r1;
        this.b2 = (Bike) r2;
    }

    private final Racing r1;
    private final Racing r2;
    private final Bicycle b1;
    private final Bike b2;

    @Override
    public void run(String... args) throws Exception {
        log.info("r1={}", r1.status());
        log.info("b1={}", b1.status());
        log.info("r2={}", r2.status());
        log.info("b2={}", b2.status());
    }
}
