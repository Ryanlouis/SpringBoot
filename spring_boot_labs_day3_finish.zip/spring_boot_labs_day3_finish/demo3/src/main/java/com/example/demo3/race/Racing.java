package com.example.demo3.race;

public interface Racing {
    public String status();
}
