package com.example.demo3.runner;

import com.example.demo3.race.Bicycle;
import com.example.demo3.race.Bike;
import com.example.demo3.race.Racing;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

@Component
@Slf4j
@Order(5)
public class ExplainDIRunner5 implements CommandLineRunner {
    @Autowired
    @Qualifier("bicycle")
    private Racing r1;
    @Autowired
    @Qualifier("bike")
    private Racing r2;
    @Autowired
    private Bicycle b1;
    @Autowired
    private Bike b2;

    @Override
    public void run(String... args) throws Exception {
        log.info("r1={}", r1.status());
        log.info("b1={}", b1.status());
        log.info("r2={}", r2.status());
        log.info("b2={}", b2.status());
    }
}
