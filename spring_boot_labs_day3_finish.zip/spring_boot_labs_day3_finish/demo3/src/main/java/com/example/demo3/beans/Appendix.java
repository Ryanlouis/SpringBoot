package com.example.demo3.beans;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Appendix {
    private String chapter = "default chapter";
    private String detail = "default detail";
}
