package com.example.demo3.runner;

import com.example.demo3.calculator.AddCalculator;
import com.example.demo3.calculator.Calculator;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

@Component
@Slf4j
@Order(3)
public class ExplainDIRunner3 implements CommandLineRunner {
    @Autowired
    @Qualifier("add")
    private Calculator cal1;
    @Autowired
    @Qualifier("sub")
    private Calculator cal2;


    @Override
    public void run(String... args) throws Exception {

        log.info("calculate 5,6 with cal1={}", cal1.calc(5, 6));
        log.info("calculate 5,6 with cal2={}", cal2.calc(5, 6));
    }
}
