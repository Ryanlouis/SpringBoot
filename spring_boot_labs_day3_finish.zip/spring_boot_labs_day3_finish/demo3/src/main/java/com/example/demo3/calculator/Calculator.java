package com.example.demo3.calculator;

public interface Calculator {
    public int calc(int a, int b);
}
