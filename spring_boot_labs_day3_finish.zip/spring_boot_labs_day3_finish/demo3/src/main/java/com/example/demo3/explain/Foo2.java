package com.example.demo3.explain;

import com.example.demo3.calculator.Calculator;
import lombok.Getter;

@Getter
public class Foo2 {
    private int x;
    private final Calculator c; // y is important, maybe can be initialized from foo1 constructor
    private int z;


    public Foo2(Calculator c) {
        this.c = c;
    }
}
