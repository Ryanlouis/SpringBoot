package com.example.demo3.beans;

import lombok.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import java.util.Date;

@Component
@Scope("prototype")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Message {
    @Value("-1")
    private int id;
    @Value("default user")
    private String name;
    private float cost;
    private boolean isValid;
    private Date date;
    private String detail;// test unicode
    private String[] referral = {"Mark", "John", "Ken"};
    private Appendix appendix = new Appendix();
}
