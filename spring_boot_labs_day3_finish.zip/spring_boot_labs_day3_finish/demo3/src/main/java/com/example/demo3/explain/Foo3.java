package com.example.demo3.explain;

import com.example.demo3.calculator.Calculator;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Getter
public class Foo3 {
    private int x;
    private final Calculator c; // y is important, maybe can be initialized from foo1 constructor
    private int z;
}
