package com.example.demo3.explain;

import com.example.demo3.calculator.Calculator;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@NoArgsConstructor
@AllArgsConstructor
public class Foo1 {
    private int x;
    private Calculator c; // y is important, maybe can be initialized from foo1 constructor
    private int z;

    public Foo1(Calculator c) {
        this.c = c;
    }
}
