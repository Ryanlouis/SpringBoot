package com.example.demo3.runner;

import com.example.demo3.race.Bicycle;
import com.example.demo3.race.Bike;
import com.example.demo3.race.Racing;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.ApplicationContext;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

@Component
@Slf4j
@Order(4)
public class ExplainDIRunner4 implements CommandLineRunner {
    public ExplainDIRunner4(ApplicationContext context) {
        this.context = context;
    }

    private ApplicationContext context;

    @Override
    public void run(String... args) throws Exception {
        Racing r1 = context.getBean("bicycle", Racing.class);
        log.info("r1={}", r1.status());
        Bicycle b1 = context.getBean(Bicycle.class);
        log.info("b1={}", b1.status());
        Racing r2 = context.getBean("bike", Racing.class);
        log.info("r2={}", r2.status());
        Bike b2 = context.getBean(Bike.class);
        log.info("b2={}", b2.status());
    }
}
