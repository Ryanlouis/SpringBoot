package com.example.demo3;

import com.example.demo3.calculator.AddCalculator;
import com.example.demo3.calculator.SubCalculator;
import com.example.demo3.explain.Foo1;
import com.example.demo3.explain.Foo2;
import com.example.demo3.explain.Foo3;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class ArgumentsTest {
    @Test
    public void initializeFoo1() {
        Foo1 foo1 = new Foo1();
        Assertions.assertNull(foo1.getC());

    }

    @Test
    public void initializeFoo2() {
        Foo2 foo2 = new Foo2(new SubCalculator());
        Assertions.assertEquals(2, foo2.getC().calc(4, 2));
    }

    @Test
    public void initializeFoo3() {
        Foo3 foo3 = new Foo3(new AddCalculator());
        Assertions.assertEquals(6, foo3.getC().calc(4, 2));
    }
}
